import React, { Component } from 'react';

class NsList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            msg:'我是一个NsList组件'
        };
    }
    render() {
        return (
            <div className="NsList">
                我是一个NsList组件
            </div>
        );
    }
}
export default NsList;
