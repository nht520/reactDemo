import React, { Component } from 'react';

class NsAbout extends Component {
    constructor(props) {
        super(props);
        this.state = {
            msg:'我是一个NsAbout组件'
        };
    }
    render() {
        return (
            <div className="NsAbout">
                我是一个NsAbout组件
            </div>
        );
    }
}

export default NsAbout;
