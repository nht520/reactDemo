import React, { Component } from 'react';
import { Route, Link } from "react-router-dom";
class News extends Component {
    constructor(props) {
        super(props);
        this.state = {
            msg:'我是一个News组件'
        };
    }
    componentWillMount(){
        console.log(this.props.routes);
    }
    render() {
        return (
            <div className="News">
                <div className="content">
                    <div className="left">
                        <Link to="/News/">新闻列表</Link>
                        <br />
                        <Link to="/News/NsAbout">新闻用户</Link>
                    </div>
                    <div className="right">
                        {
                            this.props.routes.map((route,key)=>{
                                return   <Route key={key} exact path={route.path} component={route.component} />
                            })
                        }
                        {/* <Route  path="/user/add" component={UserAdd} /> */}
                    </div>
                </div>
            </div>
        );
    }
}
export default News;
